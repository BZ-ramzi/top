<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'bddAlbret');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', 'rG98zUrj');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '@r_|>_J&cX:G[px==3Yr2k(9*>4X#Ju%:KGlSYh ?s?:RY`^j=YC dD3n$v-Z%22');
define('SECURE_AUTH_KEY',  'e#Mw5BQD& qa/z@v(9TN+Q{GMWY8nj/n;Vy,tP{PH,v=l~hjOcIuA=,PK{d)usC.');
define('LOGGED_IN_KEY',    'Fv$Wl!EO$zve%T@#6(;}t&(1VHbz]lJ]coNm$`o`Rv)R[5&ba,Ima26qcI % U>g');
define('NONCE_KEY',        'xZVtk>VaaX7{EI1>(qg,/fm){2A62>9(_ ##zq&yk/Xc42l{N)yxK`SD$/+lXX<)');
define('AUTH_SALT',        '=9f e(Z9GphqrugD&fr%ALBO|mr/JjN:Fk~A$2tn/(8F&MJHU+*Xe[^Mjy<]Jf_;');
define('SECURE_AUTH_SALT', 'xz+(KBZsaCmX1-_o};qWqtY4Mft4-5pVHE%801`Chjh?.jkm`V4Vvq-}HWiJ{__!');
define('LOGGED_IN_SALT',   'W ia||HqisE?9RI*Ax_,ck#F3TMO=#8/7 B~%h0.5)DAJC#&b>i5gdh8:dw5Rl{#');
define('NONCE_SALT',       '@r9v_ _DQ 5jjfA:|`B}Uu6bP>R:Xfc$!YYdFsXw9)X U<*|m92[=NzC8J~:@huT');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');

if(is_admin()) {
   add_filter('filesystem_method', create_function('$a', 'return "direct";' ));
   define( 'FS_CHMOD_DIR', 0751 );
}
